import 'package:flutter/material.dart';

/// PLACEHOLDER: la Parte 1 reemplaza este archivo con el tablero real.
/// Debe leer `context.read<SettingsProvider>().settings` (dificultad, estilo)
/// y llamar `context.read<ScoresProvider>().submit(GameResult(...))` al ganar.
class GameScreen extends StatelessWidget {
  const GameScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: Text('GameScreen (Parte 1)')));
}
