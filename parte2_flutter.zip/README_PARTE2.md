# Parte 2 – Arquitectura, persistencia, menús y CI/CD

## Integración
1. Crea el proyecto: `flutter create --project-name puzzle15 .`
   (el nombre del paquete debe ser `puzzle15`, o ajusta los imports de `test/`).
2. Copia `lib/`, `test/`, `.github/` y `web/manifest.json` (reemplaza el generado).
3. `flutter pub add provider shared_preferences`
4. La Parte 1 reemplaza `lib/screens/game_screen.dart` y usa:
   - `context.read<SettingsProvider>().settings` → dificultad, estilo de fichas, sonido.
   - `context.read<ScoresProvider>().submit(GameResult(...))` → al ganar (devuelve `true` si hay récord).
   - `InMemoryScoreRepository` / `InMemorySettingsRepository` para pruebas sin `shared_preferences`.

## GitHub Pages
Repo → Settings → Pages → Source: **GitHub Actions**. Cada push a `main` despliega en
`https://<usuario>.github.io/<repo>/`. El `--base-href` se calcula solo con el nombre del repo.

## Checklist PWA (Chrome DevTools → Application / Lighthouse)
- [ ] Manifest sin errores y con íconos 192/512 (y maskable) en `web/icons/`
- [ ] Service worker registrado (`flutter_service_worker.js`, lo genera `flutter build web`)
- [ ] Aparece el botón "Instalar" en Chrome/Edge
- [ ] Offline: carga una vez, activa "Offline" en DevTools → Network y recarga
- [ ] iOS Safari: Compartir → "Añadir a pantalla de inicio" (revisa `apple-touch-icon` en `web/index.html`)
- [ ] Lighthouse → categoría Installable/PWA
